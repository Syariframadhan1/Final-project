<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;

class peminjaman extends BaseController
{
    protected $peminjaman;

    function __construct()
    {
        $this->peminjaman = new PeminjamanModel();

    }

    public function index() 
    {

        $data['pageTitle'] = 'Data Peminjaman dan pengembalian';
        $data['peminjaman'] = $this->peminjaman->findAll();
        return view('dashboard/peminjaman', $data);
    }
    public function create()
    {
    $data['pageTitle'] = 'Input Data Peminjaman';
    return view('dashboard/peminjaman_create', $data);
    }
    
    public function store()
    {
    if (!$this->validate([
    'id_peminjaman' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'nama_peminjaman' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    'nama_buku' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
    
    'tanggal' => [
    'rules' => 'required',
    'errors' => [
    'required' => '{field} Harus diisi'
    ]
    ],
        'kembali' => [
        'rules' => 'required',
        'errors' => [
        'required' => '{field} Harus diisi'
        ]
        ],
 
    ])) {
    session()->setFlashdata('error', $this->validator->listErrors());
    return redirect()->back()->withInput();
    }
    
    $this->peminjaman->insert([
    'id_peminjaman' => $this->request->getVar('id_peminjaman'),
    'nama_peminjaman' => $this->request->getVar('nama_peminjaman'),
    'nama_buku' => $this->request->getVar('nama_buku'),
    'tanggal' => $this->request->getVar('tanggal'),
    'kembali' => $this->request->getVar('kembali'),


    
    ]);
    session()->setFlashdata('message', 'Tambah Data Peminjaman
    Berhasil');
    return redirect()->to('/peminjaman');
    }
    
    function edit($id_peminjaman)
        {
            $dataPeminjaman = $this->peminjaman->find($id_peminjaman);
            if (empty($dataPeminjaman)) {
                throw new
    \CodeIgniter\Exceptions\PageNotFoundException('Data Peminjaman
    Tidak ditemukan !');
            }
            $data['pageTitle'] = 'Edit Data Peminjaman';
            $data['peminjaman'] = $dataPeminjaman;
            return view('dashboard/peminjaman_edit', $data);
                   }
                   public function update($id_peminjaman)
                   {
                       if (!$this->validate([
                            'nama_peminjaman' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                            'nama_buku' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                            
                            'tanggal' => [
                            'rules' => 'required',
                            'errors' => [
                            'required' => '{field} Harus diisi'
                            ]
                            ],
                                'kembali' => [
                                'rules' => 'required',
                                'errors' => [
                                'required' => '{field} Harus diisi'
                                ]
                                ],
                         
                           
                       ])) {
                           session()->setFlashdata('error', $this->validator->listErrors());
                           return redirect()->back();
                       }
                        

                       $this->peminjaman->update($id_peminjaman, [
                        'id_peminjaman' => $this->request->getVar('id_peminjaman'),
                        'nama_peminjaman' => $this->request->getVar('nama_peminjaman'),
                        'nama_buku' => $this->request->getVar('nama_buku'),
                        'tanggal' => $this->request->getVar('tanggal'),
                        'kembali' => $this->request->getVar('kembali'),
                           
                       ]);
                       session()->setFlashdata('message', 'Update Data Peminjaman
               Berhasil');
                       return redirect()->to('/peminjaman'); 
                                 }
               
                                 function delete($id_peminjaman)
                                 {
                                     $dataPeminjaman = $this->peminjaman->find($id_peminjaman);
                                     if (empty($dataPeminjaman)) {
                                         throw new
                             \CodeIgniter\Exceptions\PageNotFoundException('Data Peminjaman
                             Tidak ditemukan !');
                                     }
                                     $this->peminjaman->delete($id_peminjaman);
                                     session()->setFlashdata('message', 'Buku Sudah di Kembalikan');
                                     return redirect()->to('/peminjaman');
                             }
    
                                           
               }
    