<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;


class MahasiswaSeeder extends Seeder
{
    public function run()
    {
        //Isi tabel mahasiswa
        $data = [
            [
                'nim' => 'C2055201017',
                'nama' => 'M. Abdul Majid',
                'jurusan' => 'Teknik Informatika',
                'jenis_kelamin' => 'pria',
                'no_telp' => '085612006600',
                'email' => 'Majide@gmail.com',
                'alamat' => 'Jl. Seth Adji No. 11, Palangka Raya',
                'created_at' => Time::now()
            ],
            [
                'nim' => 'C2055201004',
                'nama' => 'Teguh Anugerah',
                'jurusan' => 'Teknik Informatika',
                'jenis_kelamin' => 'pria',
                'no_telp' => '081255559000',
                'email' => 'Teguhja@gmail.com',
                'alamat' => 'Jl. Seth Adji No. 23, Palangka Raya',
                'created_at' => Time::now()
            ],
            [
                'nim' => 'C2055201009',
                'nama' => 'Nabila ',
                'jurusan' => 'Sistem Informasi',
                'jenis_kelamin' => 'wanita',
                'no_telp' => '081299009900',
                'email' => 'Bila@gmail.com',
                'alamat' => 'Jl. Rembulan No. 19, Palangka Raya',
                'created_at' => Time::now()
            ]
            ];
            $this->db->table('mahasiswa')->insertBatch($data);        
    }
}
