<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;


class UsersSeeder extends Seeder
{
    public function run()
    {
        // Data Tabel User yang akan kita input ke tabel users yang di database
                     $data = [
                     [
                        'username' => 'Syarif ',
                        'password' => password_hash('c0ding', PASSWORD_BCRYPT),
                        'name' => 'Syarif Ramadhan',
                        'created_at' => Time::now()
                     ]
                     ];
                            $this->db->table('users')->insertBatch($data);
    }
}
