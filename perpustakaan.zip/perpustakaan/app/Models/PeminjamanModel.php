<?php

namespace App\Models;

use CodeIgniter\Model;

class PeminjamanModel extends Model
{
    protected $table = "peminjaman";
    protected $primaryKey = "id_peminjaman";
    protected $returnType = "object";
    protected $useTimestamps = true;
    protected $allowedFields = ['id_peminjaman', 'nama_peminjaman', 'nama_buku','tanggal','kembali'];
}

